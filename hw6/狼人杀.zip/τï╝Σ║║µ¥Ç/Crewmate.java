

public interface Crewmate{
	void completeTask();
}
