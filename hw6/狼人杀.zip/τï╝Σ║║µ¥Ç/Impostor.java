public interface Impostor{
	void freeze(Player p);
	void sabotage(Player p);
}
